# tensorflow-RNN-toolkit
Convenient RNN building blocks for Tensorflow, including sequence generator, FC layer, RNN layer, etc. 


