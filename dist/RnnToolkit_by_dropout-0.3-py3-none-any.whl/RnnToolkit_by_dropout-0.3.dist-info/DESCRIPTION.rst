# tensorflow-RNN-toolkit
Convenient RNN building blocks for Tensorflow, including sequence generator, FC layer, RNN layer, etc. 

# install
```python
pip install https://github.com/drop-out/tensorflow-RNN-toolkit/raw/master/dist/RnnToolkit-by-dropout-0.3.tar.gz
```


